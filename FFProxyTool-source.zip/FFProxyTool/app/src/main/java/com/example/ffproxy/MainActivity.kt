package com.example.ffproxy

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private var selectedPackage = "com.dts.freefireth"
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("ff_config", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,16,16)
        window.navigationBarColor = Color.rgb(16,16,16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(16,16,16))
        }
        fun label(text: String, size: Float = 16f): TextView = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.WHITE); setPadding(0, 12, 0, 12)
        }
        fun button(text: String, action: () -> Unit) = Button(this).apply {
            this.text = text; setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
        }
        root.addView(label("FF PROXY TOOL", 25f))
        root.addView(label("Chọn phiên bản game"))
        val games = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val th = RadioButton(this).apply { text = "Free Fire thường"; setTextColor(Color.WHITE); id = 1 }
        val max = RadioButton(this).apply { text = "Free Fire MAX"; setTextColor(Color.WHITE); id = 2 }
        games.addView(th); games.addView(max); games.check(1)
        games.setOnCheckedChangeListener { _, id -> selectedPackage = if (id == 2) "com.dts.freefiremax" else "com.dts.freefireth" }
        root.addView(games)
        root.addView(button("CẤP QUYỀN MENU NỔI") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else status.text = "Đã có quyền hiển thị trên ứng dụng khác."
        })
        root.addView(button("START – MỞ GAME + TOUCH MENU") {
            if (!Settings.canDrawOverlays(this)) {
                status.text = "Hãy cấp quyền menu nổi trước."; return@button
            }
            startService(Intent(this, OverlayService::class.java))
            val launch = packageManager.getLaunchIntentForPackage(selectedPackage)
            if (launch != null) startActivity(launch) else status.text = "Không tìm thấy game đã chọn. Hãy cài game tương ứng."
        })
        root.addView(button("DỪNG MENU NỔI") { stopService(Intent(this, OverlayService::class.java)) })
        root.addView(label("CẤU HÌNH AIM / ESP (MÔ PHỎNG)"))
        listOf("Head", "Neck", "Chest", "ESP Box", "ESP Name", "ESP Distance", "ESP Health").forEach { name ->
            val cb = CheckBox(this).apply {
                text = name; setTextColor(Color.WHITE); isChecked = prefs.getBoolean(name, false)
                setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(name, checked).apply() }
            }
            root.addView(cb)
        }
        root.addView(label("Proxy VPN: cần máy chủ và thông tin cấu hình hợp lệ. Ứng dụng hiện chưa có endpoint proxy nên chưa thể tạo đường hầm Internet thực.", 13f))
        status = label("Trạng thái: sẵn sàng", 14f)
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
