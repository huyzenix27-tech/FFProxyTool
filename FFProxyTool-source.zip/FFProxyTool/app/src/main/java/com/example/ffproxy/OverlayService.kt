package com.example.ffproxy

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        bubbleParams = WindowManager.LayoutParams(58, 58, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 24; y = 220
        }
        val b = TextView(this).apply {
            text = "FF"; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(205, 35, 48))
            setOnTouchListener(object : View.OnTouchListener {
                var sx = 0; var sy = 0; var downX = 0f; var downY = 0f; var moved = false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { sx = bubbleParams.x; sy = bubbleParams.y; downX = e.rawX; downY = e.rawY; moved = false; return true }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                            if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) moved = true
                            bubbleParams.x = sx + dx; bubbleParams.y = sy + dy; wm.updateViewLayout(bubble, bubbleParams); return true
                        }
                        MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); return true }
                    }
                    return false
                }
            })
        }
        bubble = b; wm.addView(b, bubbleParams)
    }

    private fun togglePanel() {
        if (panel != null) { wm.removeView(panel); panel = null; return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 14, 18, 14); setBackgroundColor(Color.rgb(27,27,27)) }
        box.addView(TextView(this).apply { text = "FF PROXY PANEL"; textSize = 18f; setTextColor(Color.rgb(255,90,90)) })
        listOf("Head", "Neck", "Chest", "ESP Box", "ESP Name", "ESP Distance", "ESP Health").forEach { name ->
            box.addView(CheckBox(this).apply { text = "$name (mô phỏng)"; setTextColor(Color.WHITE) })
        }
        box.addView(Button(this).apply { text = "Đóng menu"; setOnClickListener { togglePanel() } })
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(280, WindowManager.LayoutParams.WRAP_CONTENT, type, 0, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END; x = 12; y = 180
        }
        panel = box; wm.addView(box, p)
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }; bubble?.let { wm.removeView(it) }; panel = null; bubble = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
