# FF Proxy Tool – Android source

- Android Studio project, Kotlin.
- START launches the selected installed game and displays a draggable floating touch button.
- Tapping the button opens/closes a floating demo panel.
- Head/Neck/Chest and ESP controls are UI simulation only; they do not read game memory, identify opponents, or alter Free Fire.
- Proxy VPN is not implemented as a working tunnel yet: a real upstream proxy endpoint/protocol and credentials are required. This project does not pretend that a connected status means traffic is routed.

## Build
Open this folder in Android Studio and build `app` > `assembleDebug`.

## Notes
On Android 6+, grant "Display over other apps" before pressing START. Install Free Fire or Free Fire MAX first. Package IDs used: `com.dts.freefireth` and `com.dts.freefiremax`.
